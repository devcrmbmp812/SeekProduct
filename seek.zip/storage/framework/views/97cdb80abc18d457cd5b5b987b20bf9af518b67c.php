<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="col-md-6 offset-md-3">
			<h1 class="title"><?php echo e($title); ?></h1>
			
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>