<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Register')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('register')); ?>">
                       <?php echo e(csrf_field()); ?>


                        <div class="form-group form-group has-icon-left form-control-name">
                            <label for="name" class="sr-only"><?php echo e(__('Name')); ?></label>
                            <input id="name" type="text" class="form-control form-control-lg" name="name" value="<?php echo e(old('name')); ?>" required autofocus placeholder="Enter username">

                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                        </div>

                        <div class="form-group form-group has-icon-left form-control-email">
                            <label for="email" class="sr-only"><?php echo e(__('E-Mail Address')); ?></label>
                            <input id="email" type="email" class="form-control form-control-lg" name="email" value="<?php echo e(old('email')); ?>" required placeholder="Enter email address">

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                        </div>

                        <div class="form-group form-group has-icon-left form-control-password">
                            <label for="password" class="sr-only"><?php echo e(__('Password')); ?></label>
                            <input id="password" type="password" class="form-control form-control-lg" name="password" required placeholder="Enter password">

                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                        </div>

                        <div class="form-group form-group has-icon-left form-control-password">
                            <label for="password-confirm" class="sr-only"><?php echo e(__('Confirm Password')); ?></label>
                            <input id="password-confirm" type="password" class="form-control form-control-lg" name="password_confirmation" required placeholder="Confirm password">
                        </div>

                        <div class="form-submit">
                            <button type="submit" class="btn btn-primary btn-block btn-lg">
                                        <?php echo e(__('Register')); ?>

                            </button>                       
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>