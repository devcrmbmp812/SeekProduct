@extends('layouts.app')

@section('content')
	<div class="container">
		<div class="col-md-6 offset-md-3">
			<h1 class="title">{{$title}}</h1>
			
		</div>
	</div>
@endsection